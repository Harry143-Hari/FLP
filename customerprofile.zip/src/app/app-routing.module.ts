import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderedlistComponent } from './orderedlist/orderedlist.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { CustomerprofileComponent } from './customerprofile/customerprofile.component';

import { ProductfeedbackComponent } from './productfeedback/productfeedback.component';
import { DeliverystatusComponent } from './deliverystatus/deliverystatus.component';
import { DeleteaccountComponent } from './deleteaccount/deleteaccount.component';

const routes: Routes = [
{path: '', redirectTo: '/customerprofile', pathMatch: 'full'},
{path: 'customerprofile', component: CustomerprofileComponent},
{path: 'orderedlist', component: OrderedlistComponent},
{path: 'updateprofile', component: UpdateprofileComponent},
{path: 'changepassword', component: ChangepasswordComponent},
{path: 'wishlist', component: WishlistComponent},
{path: 'deliverystatus', component: DeliverystatusComponent},
{path: 'productfeedback', component: ProductfeedbackComponent},
{path: 'deleteaccount', component: DeleteaccountComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
