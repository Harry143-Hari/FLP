import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-productfeedback',
  templateUrl: './productfeedback.component.html',
  styleUrls: ['./productfeedback.component.css']
})
export class ProductfeedbackComponent implements OnInit {

  temp: Feedback = new Feedback();

  constructor(private service: CustomerService) { }

  ngOnInit() {
  }


  save(data) {
    alert('data submitted successfully' + '  ' + data.customername);
    this.temp.name = data.customername;
    this.temp.productId = data.productId;
    this.temp.description = data.description;
    this.service.addFeedback(this.temp).subscribe(adata => console.log(adata));
  }

}
