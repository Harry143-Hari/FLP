import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {
   customer: Customer[];
  constructor(private httpClientService: CustomerService) { }

  ngOnInit() {
  }

  update() {

    this.httpClientService.updateCustomer().subscribe(data => this.customer = data);

  }






}
