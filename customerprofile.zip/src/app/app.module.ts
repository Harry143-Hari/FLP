import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { OrderedlistComponent } from './orderedlist/orderedlist.component';
import { CustomerprofileComponent } from './customerprofile/customerprofile.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ProductfeedbackComponent } from './productfeedback/productfeedback.component';
import { HttpClientModule } from '@angular/common/http';
import { DeliverystatusComponent } from './deliverystatus/deliverystatus.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DeleteaccountComponent } from './deleteaccount/deleteaccount.component';

@NgModule({
  declarations: [
    AppComponent,
    UpdateprofileComponent,
    OrderedlistComponent,
    CustomerprofileComponent,
    WishlistComponent,
    ChangepasswordComponent,
    ProductfeedbackComponent,
    DeliverystatusComponent,
    DeleteaccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
