export class Feedback {
     public  productId: number;
     public  description: string;
     public name: string;
}
