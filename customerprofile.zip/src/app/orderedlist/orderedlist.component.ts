import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Product } from '../product';

@Component({
  selector: 'app-orderedlist',
  templateUrl: './orderedlist.component.html',
  styleUrls: ['./orderedlist.component.css']
})
export class OrderedlistComponent implements OnInit {

  product: Product [];


  constructor(private httpClientService: CustomerService) { }

  ngOnInit() {

    this.httpClientService.showProducts().subscribe(data => this.product = data);


  }

}
