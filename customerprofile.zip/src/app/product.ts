
export class Product {
  productid: number;
  customerid: number;
  merchantid: number;
  productName: string;
  productPrice: number;
  quantity: number;
}

