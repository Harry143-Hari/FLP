import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feedback } from './feedback';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private baseUrl = 'http://localhost:1234';

  constructor(private http: HttpClient) {
   }


   updateCustomer(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  addFeedback(data: Feedback) {
    return this.http.post('http://localhost:1234/add', data);
  }

showProducts(id: number, value: any): Observable<Object> {
    return this.http.get('http://localhost:1234/showallprod');
    }

}



