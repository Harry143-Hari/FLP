
export class Customer {
  customerName: string;
  customerMobile: string;
  customerEmail: string;
  customerWallet: number;
}

