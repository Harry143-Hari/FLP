import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deliverystatus',
  templateUrl: './deliverystatus.component.html',
  styleUrls: ['./deliverystatus.component.css']
})
export class DeliverystatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
