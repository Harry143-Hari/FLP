package com.cg.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

public class ExceptionHandling extends Exception {
	
	String s;

	public ExceptionHandling(String s) {
		System.out.println(s);
	}
	


}
