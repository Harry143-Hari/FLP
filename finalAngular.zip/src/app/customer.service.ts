import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from './customer';
import { Observable } from 'rxjs';
import { Transaction } from './Transaction';



const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class CustomerService {
  private userUrl = 'http://localhost:9086/';
  customer: Customer;
  private accountNumber;
  constructor(private http: HttpClient) {}
  public getCustomers() {
    return this.http.get<Customer[]>(this.userUrl);
  }


  public createCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.userUrl, customer);
  }
  public showBalance(acc): Observable<Customer> {
    return this.http.get<Customer>(this.userUrl + 'balance/' + acc);
  }

  public depositAmount(acc, customer: Customer): Observable<Customer> {
    alert('Amount Deposit Successfull into Account No: ' + acc );
    return this.http.put<Customer>(this.userUrl + 'deposit/' + acc, customer);
  }

  public withdrawAmount(acc, customer: Customer): Observable<Customer> {
    alert('Amount withdrawl successfully from Account No:' + acc );
    return this.http.put<Customer>(this.userUrl + 'withdraw/' + acc, customer);
  }

  public fundTransfer(senderAccNo, recieverAccNo, customer: Customer): Observable<Customer> {
    alert('Amount Transfer Successfull from ' + senderAccNo + 'to ' + recieverAccNo );
    return this.http.put<Customer>(this.userUrl + 'transfer/' + senderAccNo + '/' + recieverAccNo, customer);
  }

  getTransactionsByAccountNumber(accountNumber): Observable<Transaction[]> {
    alert('Transactions of Account No:' + accountNumber );
    return this.http.get<Transaction[]>(this.userUrl + 'transactions/' + accountNumber );
  }
}
