package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;



@Repository
public class CustomerDaoImpl implements ICustomerDao {

	@Autowired
	ICustomerRepository repo;
	
	@Autowired
	IProductRepository productrepo;
	
	@Autowired
	IMerchantRepository merchantrepo;
	
    @Override
	public List<Customer> findAllCustomers() {
    	return repo.findAll();
	
	}


	@Override
	public List<Product> findAllProducts() {
		return productrepo.findAll();
	}


	@Override
	public void deleteCustomer(int customerId) {
		System.out.println("repo");
		System.out.println(repo.findById(customerId));
		Customer cust=repo.findById(customerId).orElse(null);
		//repo.deleteById(customerId);
		repo.delete(cust);
	}


	@Override
	public List<Merchant> findAllMerchants() {
	return merchantrepo.findAll();
	}

}
