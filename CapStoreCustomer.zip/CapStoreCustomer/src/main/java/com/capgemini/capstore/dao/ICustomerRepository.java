package com.capgemini.capstore.dao;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.capstore.beans.Customer;


@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer> {
	
//	@Query("delete from customer where customer_id=:custId")
//	public void deleteCustomerById(@Param("custId") int custId);


}
