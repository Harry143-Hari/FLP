package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.service.AdminServiceInterface;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AdminController {
	
	
	@Autowired
	AdminServiceInterface service;
	
	@GetMapping(path = "/products", produces = { "application/json" })
	public List<Product> findAllProducts() {

		return service.findAllProducts();
	}
	
	@GetMapping(path = "/customers", produces = { "application/json" })
	public List<Customer> findAllCustomers() {

		return service.findAllCustomers();
	}
	
	@GetMapping(path = "/merchants", produces = { "application/json" })
	public List<Merchant> findAllMerchants() {

		return service.findAllMerchants();
	}
	
	

	@DeleteMapping(path="/delete/{customerId}")
	public void deleteCustomer(@PathVariable int customerId) {
		System.out.println(customerId);
		System.out.println("hi");
		 service.deleteCustomer(customerId);
	}


}
