package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.service.MerchantService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")

public class MerchantController {
	
	@Autowired 
	MerchantService service;
	
	
	@PostMapping("/signupmerchant")
	public void registerMerchant(@RequestBody Merchant merchant) {
		merchant.setMerchantType("ThirdPaty Merchant");
		service.registerMerchant(merchant);
	}
	
//	@RequestMapping("/signinmerchant/{email}/{password}")
//	public Merchant loginMerchantByEmail(@PathVariable String email, @PathVariable String password) {
//		return service.loginMerchant(email, password);
//	}
	

	
	@GetMapping(value="/allMerchant")
	public List<Merchant> allMerchant(){
		//System.out.println(service.getAllMerchant().toString());
		return service.getAllMerchant();
	}
	
	

}
