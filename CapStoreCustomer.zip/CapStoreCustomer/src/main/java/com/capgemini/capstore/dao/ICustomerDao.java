package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;

public interface ICustomerDao {

	List<Customer> findAllCustomers();
	List<Product> findAllProducts();
	List<Merchant> findAllMerchants();
	public void deleteCustomer(int customerId);
	
	
	
}
