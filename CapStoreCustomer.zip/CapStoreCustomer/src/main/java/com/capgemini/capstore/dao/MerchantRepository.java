package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Merchant;

@Repository
public interface MerchantRepository extends JpaRepository<Merchant, Integer> {

//	@Query("select password from Merchant where merchantId=:id")
//	public String getPasswordById(@Param("id") int id);
//
//	@Query("from Merchant where merchantEmail=:email")
//	public Merchant getMerchantByEmail(@Param("email") String email);
}
