package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.dao.CustomerRepository;

@Service
public class CustomerService implements CustomerServiceInterface {
	
	@Autowired
	CustomerRepository repository;

	@Override
	public void addCustomer(Customer customer) {
		repository.save(customer);
	}

	@Override
	public Customer getById(int customerId) {
		return repository.findById(customerId).orElse(null);
	}

	@Override
	public List<Customer> allCustomers() {
		return repository.findAll();
	}

	

	

}
