import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-firstpage',
  templateUrl: './firstpage.component.html',
  styleUrls: ['./firstpage.component.css']
})
export class FirstpageComponent implements OnInit {

  balance:number=1000;
  customer:Customer=new Customer();

  constructor(private service:CustomerService, private router: Router) { }

  ngOnInit() {
  }

  addCustomer(data){
    alert("Hlo"+" "+data.customerName+" "+"Welcome To CapStore")
    this.customer.customerName=data.customerName;
    this.customer.customerMobile=data.customerMobile;
    this.customer.customerEmail=data.customerEmail;
    this.customer.customerPassword=data.customerPassword;
    this.service.addCustomer(this.customer).subscribe(data => console.log(data), error => console.log(error));
    //this.router.navigate(['/signin']);
    window.location.reload();
  }

}
