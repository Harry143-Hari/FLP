import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminproduct',
  templateUrl: './adminproduct.component.html',
  styleUrls: ['./adminproduct.component.css']
})
export class AdminproductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
