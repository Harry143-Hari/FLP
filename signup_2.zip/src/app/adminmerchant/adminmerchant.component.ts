import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmerchant',
  templateUrl: './adminmerchant.component.html',
  styleUrls: ['./adminmerchant.component.css']
})
export class AdminmerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
