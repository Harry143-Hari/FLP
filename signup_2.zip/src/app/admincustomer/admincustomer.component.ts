import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-admincustomer',
  templateUrl: './admincustomer.component.html',
  styleUrls: ['./admincustomer.component.css']
})
export class AdmincustomerComponent implements OnInit {

  customer: Customer[];


  constructor( private httpClientService: CustomerService) {}

  ngOnInit()  {
    this.httpClientService.showCustomers().subscribe(data => this.customer = data);
}


backtoadmin(cust) {
  alert(cust.customerId);
  this.httpClientService.deleteCustomer(cust.customerId).subscribe(data => console.log(data));
}


}
