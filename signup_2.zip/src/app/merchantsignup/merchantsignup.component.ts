import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Merchant } from '../merchant';

@Component({
  selector: 'app-merchantsignup',
  templateUrl: './merchantsignup.component.html',
  styleUrls: ['./merchantsignup.component.css']
})
export class MerchantsignupComponent implements OnInit {

  merchant:Merchant=new Merchant();
  constructor(private service:CustomerService) { }

  ngOnInit() {
  }


  signUp(all)
  {
    alert("SignUp Completed"+" "+all.value.name+" "+"Successfully")
    this.merchant.merchantEmail=all.value.emailId;
    this.merchant.merchantName=all.value.name;
    this.merchant.merchantAddress=all.value.address;
    this.merchant.merchantPassword=all.value.password;
    this.merchant.merchantMobile=all.value.phoneNo;
    this.service.addMerchant(this.merchant).subscribe(data=>{this.merchant=all});
    window.location.reload();
  }


}
