import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Customer } from './customer';
import { Observable } from '../../node_modules/rxjs';
import { Merchant } from './merchant';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }

  private baseUrl = 'http://localhost:1947'


  //Customer
  getAllCustomers(): Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allCustomer`);
  }
  getOneCustomer(customerId:number) :Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allCustomer/`+customerId)
  }

  addCustomer(customer:Customer): Observable<any>{
    return this.http.post(`${this.baseUrl}` + `/create`, customer);
  }


  //Merchant
  getAllMerchant(): Observable<any>{
    return this.http.get(`${this.baseUrl}` + `/allMerchant`);
  }
  addMerchant(merchant){
    return this.http.post<Merchant>(`${this.baseUrl}` + `/signupmerchant`, merchant);
  }
  

  //Lavanya
  showCustomers(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/allCustomer`);
  }

  deleteCustomer(id: number): Observable<any> {
    return this.http.delete(`http://localhost:1947/delete/` + id);
  }

  showMerchants(): Observable<any> {
    return this.http.get('http://localhost:1947/merchants');
  }


  showProducts(): Observable<any> {
    return this.http.get('http://localhost:1947/products');
  }

  
  
  
}
