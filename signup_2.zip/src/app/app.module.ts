import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'

import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { FirstpageComponent } from './firstpage/firstpage.component';
import { SigninComponent } from './signin/signin.component';
import { AdminsigninComponent } from './adminsignin/adminsignin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { MerchantsigninComponent } from './merchantsignin/merchantsignin.component';
import { MerchantsignupComponent } from './merchantsignup/merchantsignup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AdmincustomerComponent } from './admincustomer/admincustomer.component';
import { AdminmerchantComponent } from './adminmerchant/adminmerchant.component';
import { AdminproductComponent } from './adminproduct/adminproduct.component';

// const routes:Routes =[
//   { path: '', redirectTo: 'CapStore', pathMatch: 'full' },
//   {path:'CapStore',component:FirstpageComponent},
//   {path:'signin',component:SigninComponent}
// ];


@NgModule({
  declarations: [
    AppComponent,
    FirstpageComponent,
    SigninComponent,
    AdminsigninComponent,
    AdminpageComponent,
    MerchantsigninComponent,
    MerchantsignupComponent,
    HomepageComponent,
    AdmincustomerComponent,
    AdminmerchantComponent,
    AdminproductComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
