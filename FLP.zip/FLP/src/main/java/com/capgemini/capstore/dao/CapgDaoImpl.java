package com.capgemini.capstore.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.FeedbackForm;
import com.capgemini.capstore.beans.Purchase;

public class CapgDaoImpl implements ICapgDao{

	
	@Autowired
	DaoRepository repository;
	FeedbackRepository feedbackrepo;
	ProductRepository productrepo;

	public ResponseEntity<Customer> updateCustomer(int customerId){
		
		//System.out.println("Update Customer with ID = " + customerId + "...");

		Optional<Customer> customerData = repository.findById(customerId);
		
		if (customerData.isPresent()) {
			Customer customer = customerData.get();
			customer.getCustomerEmail();
			customer.getCustomerMobile();
			customer.getCustomerName();
			customer.getCustomerWallet();
			return new ResponseEntity<>(repository.save(customer), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		
	}
	
	@Override
	public void add(FeedbackForm objectForm) {
	
		
		feedbackrepo.save(objectForm);
	}

	@Override
	public List<FeedbackForm> findAllFeedback() {
		
		return feedbackrepo.findAll();	
	}
	
	
	@Override
	public List<Purchase> findAllProducts() {
		
		return productrepo.findAll();	
	}
	
	
}
