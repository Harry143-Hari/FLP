package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.FeedbackForm;
import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.service.CapgService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CapgController {
	
	@Autowired
	CapgService service;

	
	@PutMapping("/customers/{id}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable("id") int customerId, @RequestBody Customer customer) {
		
		return service.updateCustomer(customerId);
	}
	
	@PostMapping(value="/add")
    public void add(@RequestBody FeedbackForm form)
    {
    	System.out.println("hi");
         service.add(form);
    }

    @GetMapping("/GetAll")
    public List<FeedbackForm> getAll()
    {
         return service.findAllFeedback();
    }
	
    
    @GetMapping("/GetAllProducts")
    public List<Purchase> getAllProducts()
    {
         return service.findAllProducts();
    }
    
    
    @DeleteMapping("/deleteAccount/{id}")
    public void deleteAcc() {
    	
    	
    }
	
}
	
	
	
	

