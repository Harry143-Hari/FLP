package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity(name="CAPGPURCHASE")
public class Purchase {
    @Id
    @SequenceGenerator(name="seq" , sequenceName = "product_sequence")
    @GeneratedValue(generator = "seq")
    int productID;
    String productName;
    double quantity;
    int customerID;
    int merchantID;
    double productPrice;
    public int getProductID() {
        return productID;
    }
    public void setProductID(int productID) {
        this.productID = productID;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public double getQuantity() {
        return quantity;
    }
    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }
    public int getCustomerID() {
        return customerID;
    }
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
    public int getMerchantID() {
        return merchantID;
    }
    public void setMerchantID(int merchantID) {
        this.merchantID = merchantID;
    }
    public double getProductPrice() {
        return productPrice;
    }
    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
    @Override
    public String toString() {
        return "Purchase [productID=" + productID + ", productName=" + productName + ", quantity=" + quantity
                + ", customerID=" + customerID + ", merchantID=" + merchantID + ", productPrice=" + productPrice + "]";
    }

 

    
}