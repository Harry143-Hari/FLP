package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.FeedbackForm;
import com.capgemini.capstore.beans.Purchase;

public interface ICapgDao {

	public ResponseEntity<Customer> updateCustomer(int customerId);
	
	
	public void add(FeedbackForm objectForm);
	
	
	public List<FeedbackForm> findAllFeedback();
	
	public List<Purchase> findAllProducts();
	
	
}
