package com.capgemini.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.FeedbackForm;
import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.dao.DaoRepository;
import com.capgemini.capstore.dao.FeedbackRepository;
import com.capgemini.capstore.dao.ICapgDao;



@Service
public class CapgService implements CapgServiceIntf {
	
	
	@Autowired
	ICapgDao dao;

	@Override
	public ResponseEntity<Customer> updateCustomer(int customerId) {
		return dao.updateCustomer(customerId);
	}

	@Override
	public void add(FeedbackForm objectForm) {
		
		dao.add(objectForm);
	}

	@Override
	public List<FeedbackForm> findAllFeedback() {
		
		return dao.findAllFeedback();
		
	}
	
	@Override
	public List<Purchase> findAllProducts() {
		
		return dao.findAllProducts();
		
	}

	
	
	
	
	
	
}
