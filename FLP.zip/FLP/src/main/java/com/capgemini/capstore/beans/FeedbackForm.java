package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class FeedbackForm {
	
	@Id
    private int productId;
    private String description;
    private String name;
    public FeedbackForm()
    {
    	
    }
	public FeedbackForm(String name, int productId, String description) {
		super();
		this.name = name;
		this.productId = productId;
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

   
}
